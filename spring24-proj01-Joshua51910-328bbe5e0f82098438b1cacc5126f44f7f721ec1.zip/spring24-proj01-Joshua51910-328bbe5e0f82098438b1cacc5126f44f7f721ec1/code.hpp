#ifndef CODE_HPP
#define CODE_HPP

#include <iostream>
#include <string>

int string_to_int(std::string input, int ibase);

std::string int_to_string(int value, int obase);

void convert(std::istream& sin, std::ostream& sout, int ibase, int obase);

#endif // CODE_HPP
