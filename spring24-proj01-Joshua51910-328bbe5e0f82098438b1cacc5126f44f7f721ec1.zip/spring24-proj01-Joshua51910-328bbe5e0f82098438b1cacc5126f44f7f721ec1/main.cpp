#include "code.hpp"

#include <iostream>

int main() {
    
    int ibase{};
    std::cout << "What is the input base? ";
    std::cin >> ibase;

    int obase{};
    std::cout << "What is the output base? ";
    std::cin >> obase;
    
    convert(std::cin, std::cout, ibase, obase);

    return 0;
}
