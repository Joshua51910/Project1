#include "code.hpp"

int string_to_int(std::string input, int ibase) {
    // TODO
}

std::string int_to_string(int value, int obase) {
    // TODO
}

void convert(std::istream& sin, std::ostream& sout, int ibase, int obase) {
    // TODO
}
