#include <catch2/catch_test_macros.hpp>
#include <catch2/matchers/catch_matchers_floating_point.hpp>

#include "code.hpp"

#include <sstream>

TEST_CASE("string_to_int valid cases") {
    REQUIRE(string_to_int("0", 2) == 0);
    REQUIRE(string_to_int("11011", 2) == 0b11011);
    REQUIRE(string_to_int("11111111", 2) == 0b11111111);

    REQUIRE(string_to_int("0", 10) == 0);
    REQUIRE(string_to_int("128", 10) == 128);
    REQUIRE(string_to_int("1023", 10) == 1023);

    REQUIRE(string_to_int("0", 8) == 0);
    REQUIRE(string_to_int("077", 8) == 077);
    REQUIRE(string_to_int("377770", 8) == 0377770);
}

TEST_CASE("int_to_string valid cases") {
    REQUIRE(int_to_string(0, 2) == "0");
    REQUIRE(int_to_string(0b11011, 2) == "11011");
    REQUIRE(int_to_string(0b11111111, 2) == "11111111");

    REQUIRE(int_to_string(0, 10) == "0");
    REQUIRE(int_to_string(128, 10) == "128");
    REQUIRE(int_to_string(1023, 10) == "1023");

    REQUIRE(int_to_string(0, 8) == "0");
    REQUIRE(int_to_string(077, 8) == "77");
    REQUIRE(int_to_string(0377770, 8) == "377770");
}

TEST_CASE("convert") {

    // Start with a simple binary to decimal convertion
    std::stringstream sin { "1\n11\n11011\n101010\n11111111\nx\n" };
    std::stringstream sout;
    convert(sin, sout, 2, 10);
    REQUIRE(sout.str() == "1\n3\n27\n42\n255\n");

    // Now an octal to decimal conversion
    sin.str("077\n377770\nx\n");
    sout.str("");
    convert(sin, sout, 8, 10);
    REQUIRE(sout.str() == "63\n131064\n");

    // Binary to octal
    sin.str("1\n11\n11011\n101010\n11111111\nx\n");
    sout.str("");
    convert(sin, sout, 2, 8);
    REQUIRE(sout.str() == "1\n3\n33\n52\n377\n");

    // Octal to binary
    sin.str("1\n3\n33\n52\n377\nx\n");
    sout.str("");
    convert(sin, sout, 8, 2);
    REQUIRE(sout.str() == "1\n11\n11011\n101010\n11111111\n");
}

TEST_CASE("string_to_int invalid cases") {
    REQUIRE(string_to_int("0", 0) == -1);
    REQUIRE(string_to_int("0", 1) == -1);
    REQUIRE(string_to_int("0", 11) == -1);
    REQUIRE(string_to_int("0", 12) == -1);

    // TODO: possibly remove
    REQUIRE(string_to_int("-1", 2) == -1);
    REQUIRE(string_to_int("12", 2) == -1);
    REQUIRE(string_to_int("a", 2) == -1);
    REQUIRE(string_to_int("18", 8) == -1);
}

TEST_CASE("int_to_string invalid cases") {
    REQUIRE(int_to_string(0, 0).empty());
    REQUIRE(int_to_string(0, 1).empty());
    REQUIRE(int_to_string(0, 11).empty());
    REQUIRE(int_to_string(0, 12).empty());

    REQUIRE(int_to_string(-1, 2).empty());
}

TEST_CASE("convert invalid cases") {
    std::stringstream sin { "1\n11\n11012\n101010\n11111111\nx\n" };
    std::stringstream sout;
    convert(sin, sout, 1, 2);
    REQUIRE(sout.str().empty());
    convert(sin, sout, 2, 1);
    REQUIRE(sout.str().empty());
    convert(sin, sout, 1, 2);
    REQUIRE(sout.str().empty());
    convert(sin, sout, 2, 1);
    REQUIRE(sout.str().empty());
    convert(sin, sout, 2, 10);
    REQUIRE(sout.str() == "1\n3\n42\n255\n");
}
